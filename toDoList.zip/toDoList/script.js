let limparInformacoes = () => {
    localStorage.clear();
    window.location.reload();
}

let preencherTabela = () => {
    localStorage.getItem("totAtividades") || localStorage.setItem("totAtividades", 0);
    localStorage.getItem('dia') || localStorage.setItem("dia", '[]');

    let planilha =  JSON.parse(localStorage.getItem('dia'));

    var table = document.getElementById("table-dia");

    for ( indice in planilha){
        let partida = planilha[indice];
        
        var row = table.insertRow(parseInt(indice) + 1);
    
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
    }
}

let salvarJogadores = () => {
    
    let usuario = document.getElementsByClassName("usuario");

    if ( localStorage.contains(usuario[0])) {
        alert("Não pode haver usuários com mesmos username");
    } else {
        localStorage.setItem("usuario", usuario[0].value);

        iniciarPlanilha();
    }  
}

let iniciarPlanilha = () => {

    document.getElementsByClassName("planilha")[0].style.display = "flex";
    document.getElementsByClassName("inicio")[0].style.display = "none";
    document.getElementsByClassName("dia")[0].style.display = "none";
    
    document.getElementById("user").innerHTML = localStorage.getItem("usuario");
    
    localStorage.setItem("acertosUsuario", 0);
}
